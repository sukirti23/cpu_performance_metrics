#!/bin/bash

# the script accepts one argument to indidate the output file where the perf results are appended to. 
# e.g., ./run.sh perf-result-file


for i in 4 8
do
	echo "=== test run with $i threads ===" >> $1  
	perf stat -o $1 --append ./fluidanimate $i 20 in_500K.fluid out.fluid

done
